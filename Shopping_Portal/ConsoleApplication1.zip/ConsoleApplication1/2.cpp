#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "shopping.h"
#include "admin.h"




    








int login(string username, string password, int log)
{

    ifstream in("login.txt");
    if (!in) {
        cerr << "Failed to open the file." << endl;
        return 1;
    }

    string line;
    string category;
    int c = 0;
    bool mark = false;

    while (getline(in, line)) {
        if (line.length() > 2)
        {
            if (line.find("->") != string::npos && mark == false)
            {
                category = line.substr(2);
                if (category == to_string(log))
                {
                    mark = true;
                }
            }

            else if (mark == true && line.substr(2) == category)
            {
                return 0;
            }
        }

        if (mark == true)
        {
            if (line == username && mark == true && c == 0)
            {
                c++;
            }
            else if (c == 1 && line == password)
            {
                return 1;
            }
        }


    }

    in.close();
}




int main()
{
loginpagel:
   
        cout << "Welcome to Shop. Please Select from the following options\n";
        char charopt;
        int log, iopt, choice; bool registered = true;
        string username, password;
        Customer customer;
        StoreManager store_manager;
        Vendor vendor;
        Cart cart;
        Invoicing invo;

        Admin adm;
        adm.UpdateProducts();

    //    cout << "1. Admin\n2. Customer\n3. Vendor\n";
    //logl:
    //    std::cin >> log;
    //    if (log > 0 && log < 4)
    //    {
    //        cout << "Now enter your login details\n";
    //    }
    //    else if (log == 2)
    //    {
    //        cout << "Are you a registered [C]ustomer or a [G]uest\n";
    //    regguestnono:
    //        cin >> charopt;
    //        if (charopt == 'G' || charopt == 'G')
    //        {
    //            cout << "We highly recommend you register yourself as the registered Customer get to enjoy 5% discount on their every order\nRegardless you can shop as a guest as well.\n";
    //            registered = false;
    //        }
    //        else if (charopt == 'R' || charopt == 'R')
    //        {
    //            cout << "Please enter your login details\n";
    //        }
    //        else
    //        {
    //            cout << "Invalid Choice. Please enter again\n";
    //            goto regguestnono;
    //        }
    //    }
    //    else
    //    {
    //        cout << "Invalid option selected. Please renter the correct choice\n";
    //        goto logl;
    //    }
    //    if (registered != false)
    //    {
    //        cout << "Enter your username\n";
    //        std::cin >> username;

    //        cout << "Admin enter your password\n";
    //        std::cin >> password;
    //    }

    //    int log_f;
    //    log_f = login(username, password, log);
        //if (log_f == 0 && log == 2)
        //{
        //    cout << "Customer not registered in database. Do you want to register yourself? [Y] or [N]\n";
        //    yesnol:
        //    std::cin >> charopt;
        //    if (charopt == 'Y' || charopt == 'y')
        //    {
        //        //registercustomer();

        //    }
        //    else if (charopt == 'n' || charopt == 'n')
        //    {
        //        //goto loginpagel;
        //    }
        //    else
        //    {
        //        cout<<"Invalid Choice. Please enter again\n";
        //        goto yesnol;
        //    }

        //}

       /* if (log_f == 1)
        {
            if (log == 1)
            {
                cout << "Welcome " << 1 << " You have unlocked all the privilidges of the Admin\n";
            }
            else if (log == 2)
            {
                cout << "Welcome " << username << ". Happy Shopping!\n";
            catmenul:
                customer.menu();
            catenterl:
                cout << "Please enter the category";

                cin >> iopt;
                customer.menuofProducts(customer.getCategoryName(iopt - 1));
                cout << "\n\nEnter the product you want to add to cart\n";
                cin >> iopt;
                if (customer.in_Stock(iopt - 1) == true)
                {
                    cout << "Enter the number of products you want to buy\n";
                    int p;
                quantitynono:
                    cin >> p;

                    if (store_manager.updateItem(customer.getProducts(iopt - 1), p) == true)
                    {
                        cart.addtoCart(customer.getProducts(iopt - 1), p);
                        cout << "Item added to cart\n Please choose from the following\n";
                        cout << "1. Go back to Main Menu\n2. View More Products\n3. Change Category\n4. View Cart\n5. Checkout";
                        cin >> choice;
                        if (choice == 1)
                        {
                            goto logl;
                        }
                        else if (choice == 2)
                        {
                            goto catmenul;
                        }
                        else if (choice == 3)
                        {
                            goto catenterl;
                        }
                        else if (choice == 4)
                        {
                            cart.viewCart();
                        }
                        else if (choice == 5)
                        {
                            cart.calculateSumTotal();
                            invo.displayInvoice(cart, 2);
                        }
                    }
                    else
                        goto quantitynono;
                }
                else
                {
                    cout << "Sorry out of stock\n";
                }
            }
            else
                cout << "wrong again\n";

        }
        else if (log == 3)
        {
            cout << "Welcome" << " You have unlocked all the privilidges of the Vendor";
        }
        */

    

}
